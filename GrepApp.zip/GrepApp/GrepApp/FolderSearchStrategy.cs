﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GrepApp
{
    public class FolderSearchStrategy : ISearchstrategy
    {
        public IEnumerable<string> Search(string path, string searchTerm, bool caseInsensitive, bool reverseSearch)
        {
            if (!Directory.Exists(path))
            {
                yield return $"Folder not found: {path}";
                yield break;
            }

            var files = Directory.GetFiles(path);
            var fileSearch = new FileSearchStrategy();

            foreach(var file in files)
            {
                foreach(var result in fileSearch.Search(file, searchTerm, caseInsensitive, reverseSearch))
                {
                    yield return result;

                }
            }
        }
    }
}
