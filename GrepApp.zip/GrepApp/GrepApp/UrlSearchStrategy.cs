﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace GrepApp
{
    public class UrlSearchStrategy : ISearchstrategy
    {
        public IEnumerable<string> Search(string path, string searchTerm, bool caseInsensitive, bool reverseSearch)
        {
            var results = new List<string>();
            using (var wc = new WebClient())
            {
                string webData;
                try
                {
                    webData = wc.DownloadString(path);
                }

                catch (WebException)
                {
                    results.Add($"Failed to download content from URL: {path}");
                    return results;
                }

                var lines = webData.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                var comparison = caseInsensitive ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

                foreach(var line in lines)
                {
                    bool match = line.IndexOf(searchTerm, comparison) >= 0;
                    if(reverseSearch ? !match : match)
                    {
                        results.Add($"{path}:{line}");
                    }
                }
            }

            return results;
        }
    }
}
