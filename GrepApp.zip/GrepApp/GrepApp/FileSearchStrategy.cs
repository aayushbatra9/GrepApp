﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GrepApp
{
    public class FileSearchStrategy : ISearchstrategy
    {
        public IEnumerable<string> Search(string path, string searchTerm, bool caseInsensitive, bool reverseSearch)
        {
            if(!File.Exists(path))
            {
                yield return $"File not found: {path}";
                yield break;
            }

            var lines = File.ReadAllLines(path);
            var comparison = caseInsensitive ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

            foreach(var line in lines)
            {
                bool match = line.IndexOf(searchTerm, comparison) >= 0;
                if(reverseSearch? !match: match)
                {
                    yield return $"{path}:{line}";
                }
            }
        }
    }
}
