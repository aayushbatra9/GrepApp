﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrepApp
{
    public interface ISearchstrategy
    {
        IEnumerable<string> Search(string path, string searchTerm, bool caseInsensitive, bool reverseSearch);
    }
}
