﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrepApp
{
    public class SearchContext
    {
        private readonly ISearchstrategy _strategy;

        public SearchContext(ISearchstrategy strategy)
        {
            _strategy = strategy;
        }

        public void ExecuteSearch(string path, string searchterm, bool caseInsensitive, bool reverseSearch)
        {
            foreach(var result in _strategy.Search(path, searchterm, caseInsensitive, reverseSearch))
            {
                Console.WriteLine(result);
            }
        }
    }
}
