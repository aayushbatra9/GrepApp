﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace GrepApp
{
    class Program
    {
        static void Main(string[] args)
        {
            bool reverseSearch = args.Contains("-v");
            bool caseInsensitive = args.Contains("-i");

            string searchTerm = args.FirstOrDefault(arg => !arg.StartsWith("-") && !arg.Contains(":"));
            if(string.IsNullOrEmpty(searchTerm))
            {
                Console.WriteLine("Search term not provided.");
                return;
            }

            var sources = args.Where(arg => arg.Contains(":")).ToList();
            if(sources.Count == 0)
            {
                Console.WriteLine("No Source provided.");
                return;
            }

            foreach(var source in sources)
            {
                var parts = source.Split(new[] {':'}, 2);
                if (parts.Length != 2)
                {
                    Console.WriteLine($"Error: Invalid Source format '{source}'");
                    continue;
                }
                var type = parts[0];
                var path = parts[1];

                ISearchstrategy strategy;
                switch(type.ToLower())
                {
                    case "file":
                        strategy = new FileSearchStrategy();
                        break;

                    case "folder":
                        strategy = new FolderSearchStrategy();
                        break;

                    case "url":
                        strategy = new UrlSearchStrategy();
                        break;

                    default:
                        Console.WriteLine($"Unknown source type: {type}");
                        continue;

                }

                var context = new SearchContext(strategy);
                context.ExecuteSearch(path, searchTerm, caseInsensitive, reverseSearch);
            }
        }
    }
}
